import numpy as np

from src.Groove import InputGroove
from src.ModelAPI import VAEDrumGrooveTransformer
from src.UartIOMessageManager import OutgoingMessageManager, IncomingMessage
from src.State import LatentState

# Test
model_path = "src/model/VAE/trained"
model_name = "100.pth"

model = VAEDrumGrooveTransformer(model_name, model_path)

from src.Groove import InputGroove

h = np.random.randint(0, 2, 32)
v = np.random.rand(32) * h
o = (np.random.rand(32) - 0.5) * h
g = np.stack((h, v, o)).transpose()

input_groove = InputGroove(original_groove=g)
input_groove.set_vel_change_amount(0)
input_groove.set_inversion_amount(0)

l_z = model.encode_into_latent_z(input_groove.scaled)
print(l_z.shape)

# Test generation
voice_thresholds = [0.5] * 9
voice_max_count_allowed = [32] * 9

(h, v, o), tempered_probs = model.generate_from_groove(
    in_groove=input_groove.scaled,
    voice_thresholds_=voice_thresholds,
    voice_max_count_allowed_=voice_max_count_allowed,
    temperature_=1.0,
)

# load MessageManager
mm = OutgoingMessageManager(uartMessagesJson="src/uartMessages.json")
mm.getMessagesForGeneratedGroove(h_new=h, v_new=v, o_new=o, prob_new=tempered_probs)


# test incoming message groove
msg = "G/12/100/500\n"
im = IncomingMessage(uartMessagesJson="./src/uartMessages.json", message=msg)
im.value

# test incoming message save to state A
msg = "SA/"
im = IncomingMessage(uartMessagesJson="./src/uartMessages.json", message=msg)

# test density pot 2 value
msg = "DP/2/100\n"
im = IncomingMessage(uartMessagesJson="./src/uartMessages.json", message=msg)
im.value
im.isDensityPot


