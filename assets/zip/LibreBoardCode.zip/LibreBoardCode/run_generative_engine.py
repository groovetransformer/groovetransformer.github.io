"""
    In this mode, the latent_z (playback_latent_z) used for playback is an interpolation of A and B and Groove
        (scaled by the slider and the FOLLOW (GEN 03) pot)

    The parameters used for generation are however not calculated the same way.
        1. playback_UI_state is used for generation
        2. At start up, playback_latent_z is set to the weighted average of A and B depending on the interp slider
        3. When the interp slider is moved, the new value is calculated as an interpolation of it's previous value and
            A preset (if moving left), or B preset (if moving right)
        4. At anytime, if the user moves one of the density pots, the previous corresponding value in playback_UI_state
            is overriden with the new value

    At anytime that a pattern is saved to A and B the existing playback_latent_z and playback_UI_state are stored at
        the corresponding index in the state list. Depending on the --update_existing_state_after_AB_change flag, the
        existing playback_latent_z and playback_UI_state are either kept or updated to the new values (see help below for
        --update_existing_state_after_AB_change flag)

    The following ui parameters are the ones always interpolated:
        1. Density pots 1-6
        2. Temperature (Uncertainty) pot
    The following two should be interpolated only when the corresponding flags are set:
        1. Velocity scale pot (if --interpolate_velocity_scale is set to True)
        2. Offset quantization pot (if --interpolate_offset_quantization is set to True)
        3. Groove Inversion (Gen Pot 01) (if --interpolate_groove_inversion is set to True)
"""

import torch
import time
from src.ModelAPI import VAEDrumGrooveTransformer
from src.UartIOMessageManager import OutgoingMessageManager, IncomingMessage
from src.State import LatentState, UIState
import copy
import datetime
import glob

try:
    import serial
    __HAS_SERIAL__ = True
except:
    print('serial not found')
    __HAS_SERIAL__ = False

import argparse
import os
import pickle

# /dev/ttyAML6 for GPIO UART -->
# https://hub.libre.computer/t/how-to-enable-uart-a-and-921600-baud-rate-for-aml-s805x-ac-and-aml-s905x-cc/166

parser = argparse.ArgumentParser(description='Monotonic Groove to Drum Generator')
parser.add_argument('--wait', type=float, default=0.01,
                    help='minimum rate of wait time (in seconds) '
                         'between two executive generation (default = 2 seconds)',
                    required=False)
parser.add_argument('--device', type=str, default='/dev/ttyAML6',
                    help='device for serial communication, default is /dev/ttyAML6',
                    required=False)
parser.add_argument('--baudrate', type=int, default=4800,
                    help='baudrate for serial communication, default is 4800',
                    required=False)
parser.add_argument('--model_path', type=str, default='src/model/VAE/trained',
                    help='path to the trained model (default = src/model/VAE/trained)',
                    required=False)
parser.add_argument('--model_name', type=str, default='genialwind10_140.pth',
                    help='name of the trained model (default = genialwind10_140.pth)',
                    required=False)
parser.add_argument('--debug', type=int, default=0)
parser.add_argument('--presets_dir', type=str, default='./presets',
                    help='directory of presets (default = presets)',
                    required=False)
parser.add_argument('--update_existing_state_after_AB_change', type=int, default=0,
                    help='update existing state after save. (default = 0). If True, anytime a save to A or B is '
                         'requested, the existing UI state is recalculated by interpolating between A and B and '
                         'existing latent is recalculated between A and B and groove',
                    required=False)
parser.add_argument('--interpolate_velocity_scale', type=int, default=0,
                    help='Interpolate velocity scale (default = 0). If True, velocity scale is interpolated between '
                         'A and B',
                    required=False)
parser.add_argument('--interpolate_offset_quantization', type=int, default=0,
                    help='Interpolate offset quantization (default = 0). If True, offset quantization is interpolated '
                         'between A and B',
                    required=False)
parser.add_argument('--interpolate_groove_inversion', type=int, default=0,
                    help='Interpolate groove inversion (default = 0). If True, groove inversion is interpolated '
                         'between A and B',
                    required=False)

args = parser.parse_args()

interpolate_velocity_scale = args.interpolate_velocity_scale == 1
interpolate_offset_quantization = args.interpolate_offset_quantization == 1
interpolate_groove_inversion = args.interpolate_groove_inversion == 1

if __HAS_SERIAL__:
    print("Starting serial communication")
    ser = serial.Serial(args.device,
                        baudrate=args.baudrate,
                        timeout=1, stopbits=serial.STOPBITS_ONE, parity=serial.PARITY_NONE,
                        bytesize=serial.EIGHTBITS)
    print("started serial communication")


def send_single_message_to_seed(msg_):
    assert isinstance(msg_, str), 'msg must be a string'
    if not msg_.endswith('\n'):
        msg_ += '\n'

    if __HAS_SERIAL__:
        ser.write(msg_.encode('utf-8'))
        if args.debug == 1:
            print("MESSAGE SENT ", msg_)
    else:
        print('Serial not found, skipping message: {}'.format(msg_))


def get_message(uartMessagesJson="src/uartMessages.json"):
    daisyMessage_ = ser.readline()  # Read the incoming data from the Daisey

    try:
        daisyMessage_ = daisyMessage_.decode('ascii').strip()
        return IncomingMessage(message=daisyMessage_, uartMessagesJson=uartMessagesJson)
    except:
        print(f"Error reading message {daisyMessage_}")
        return None


def save_preset(presets_dir, preset_bank, preset_ix):
    """
    Saves the current state to a preset directory (doesn't overwrite existing presets - appends to the sequence of
    existing presets)
     e.g. if presets/0/0 exists, then it will save to presets/0/1
    Loading will load the most recent preset in the sequence
    :param presets_dir:
    :param preset_bank:
    :param preset_ix:
    :return:
    """
    global groove_state, state_A_latent_z, state_B_latent_z, state_A_UI_state, state_B_UI_state, playback_UI_state

    # path formatted as "presets/presets_ix/Count/"
    path = os.path.join(presets_dir, f"bank_{str(preset_bank)}", f"preset_{str(preset_ix)}")
    os.makedirs(path, exist_ok=True)

    # with glob find all files in path that contain "Version"
    directories = glob.glob(os.path.join(path, "*Version*"))
    directories = sorted(directories, key=lambda x: int(x.split("Version")[-1]))

    if len(directories) > 0:
        # find the latest version number
        latest_file = directories[-1]
        latest_version = int(latest_file.split("Version")[-1]) + 1
    else:
        latest_version = 0

    # create the next version
    next_version = os.path.join(path, f"Version{latest_version}")
    os.makedirs(next_version, exist_ok=True)

    # collect all the files to save
    preset_data = {
        "groove_state": groove_state,
        "state_A_latent_z": state_A_latent_z,
        "state_B_latent_z": state_B_latent_z,
        "state_A_UI_state": state_A_UI_state,
        "state_B_UI_state": state_B_UI_state,
        "playback_UI_state": playback_UI_state,
        "model_name": args.model_name,
        "model_path": args.model_path,
    }

    # write the saved time to a file
    with open(os.path.join(next_version, "saved_time.txt"), 'w') as f:
        f.write(str(datetime.datetime.now()))

    # save all the data
    with open(os.path.join(next_version, "data"), 'wb') as f:
        pickle.dump(preset_data, f)

    # print the directory
    # if args.debug == 1:
        print("Preset saved to: ", next_version)


def load_preset(presets_dir, preset_bank, preset_ix):
    """
    Loads the most recent preset in the sequence
    :param presets_dir:
    :param preset_bank:
    :param preset_ix:
    :return:
    """
    global model, groove_state, state_A_latent_z, state_B_latent_z, state_A_UI_state, state_B_UI_state, clean_start, \
        are_all_updated, playback_UI_state

    # path formatted as "presets/presets_ix/Count/"
    # create path
    path = os.path.join(presets_dir, f"bank_{str(preset_bank)}", f"preset_{str(preset_ix)}")
    # use glob to find all subdirectories in path that start with "Version"
    directories = []
    if os.path.exists(path):
        directories = sorted(glob.glob(os.path.join(path, "Version*")))

    print("Existing directories: ", directories, "\n")

    if len(directories) == 0:
        print("\n" + ("!" * 100))
        print("No presets found in ", path)
        clean_start = True
        are_all_updated = True
        return

    else:
        directories = sorted(directories, key=lambda x: int(x.split("Version")[-1]))

        # find the most recent directory (by version number)
        most_recent_dir = directories[-1].split("Version")[-1]

        # loading message
        print("Loading preset from: ", os.path.join(path, str(most_recent_dir)))

        # load the data
        with open(os.path.join(path, f"Version{most_recent_dir}", "data"), 'rb') as f:
            preset_data = pickle.load(f)
            print("[load_preset] Preset data: ", preset_data)
            model = VAEDrumGrooveTransformer(preset_data["model_name"], preset_data["model_path"])
            groove_state = preset_data["groove_state"]
            state_A_latent_z = preset_data["state_A_latent_z"]
            state_B_latent_z = preset_data["state_B_latent_z"]
            state_A_UI_state = preset_data["state_A_UI_state"]
            state_B_UI_state = preset_data["state_B_UI_state"]
            playback_UI_state = preset_data["playback_UI_state"]

            if state_A_UI_state is None:
                state_A_UI_state = copy.deepcopy(playback_UI_state)
            if state_B_UI_state is None:
                state_B_UI_state = copy.deepcopy(playback_UI_state)

            if args.debug == 1:
                print("**"*20)
                print("Preset loaded successfully from: ", os.path.join(path, str(most_recent_dir)))

        are_all_updated = True


def act_on_incoming_message(incoming_message):
    """returns True if a request is made to crash the app, otherwise returns False  """
    global groove_state, state_A_latent_z, state_B_latent_z, playback_latent_z, state_A_UI_state, state_B_UI_state,  \
        playback_UI_state, new_slider_position, follow_amount_pot, variance_scaling_factor_gp2

    global is_groove_updated, is_state_A_updated, is_state_B_updated, are_density_pots_updated, \
        is_slider_position_updated, is_follow_amount_pot_updated, is_temperature_pot_updated

    if incoming_message is None:
        return False

    # --------- Check if the incoming message is a request to force crash app (for testing)
    if incoming_message.shouldForceCrashAppForDebugging:
        return True

    # -------- Check if the incoming message is a new groove onset
    if incoming_message.isNewGrooveOnset:
        ts, v, o = incoming_message.value
        groove_state.groove.add_event(ts, v, o)
        is_groove_updated = True

    if incoming_message.isInputGrooveVelocityScale:
        playback_UI_state.groove_velocity_gain = incoming_message.value
        groove_state.groove.set_vel_change_amount(playback_UI_state.groove_velocity_gain)
        is_groove_updated = True

    if incoming_message.isInputGrooveOffsetQuantization:
        playback_UI_state.groove_offset_quantization = incoming_message.value
        groove_state.groove.set_offset_quantization(playback_UI_state.groove_offset_quantization)
        is_groove_updated = True

    if incoming_message.isRandomnessPot:
        playback_UI_state.temperature = incoming_message.value
        is_temperature_pot_updated = True

    if incoming_message.isDensityPot:
        pot_ix, pot_value = incoming_message.value
        playback_UI_state.trigger_pots[pot_ix] = pot_value
        are_density_pots_updated = True

    if incoming_message.isGeneralPurposePot:
        pot_ix, pot_value = incoming_message.value
        playback_UI_state.general_purpose_pots[pot_ix] = pot_value
        if pot_ix == 0:
            playback_UI_state.groove_inversion = pot_value
            is_groove_updated = True
        elif pot_ix == 1:
            variance_scaling_factor_gp2 = (pot_value + 1.0) * 5
        elif pot_ix == 2:
            follow_amount_pot = pot_value
            is_follow_amount_pot_updated = True

    if incoming_message.isInterpolationSlider:
        new_slider_position = incoming_message.value
        is_slider_position_updated = True

    if incoming_message.shouldSaveToStateA:
        state_A_UI_state = copy.deepcopy(playback_UI_state)
        state_A_latent_z = copy.deepcopy(playback_latent_z)
        is_state_A_updated = True

    if incoming_message.shouldSaveToStateB:
        state_B_UI_state = copy.deepcopy(playback_UI_state)
        state_B_latent_z = copy.deepcopy(playback_latent_z)
        is_state_B_updated = True

    if incoming_message.shouldRandomizeStateA:
        state_A_latent_z = model.generate_random_z()
        is_state_A_updated = True

    if incoming_message.shouldRandomizeStateB:
        state_B_latent_z = model.generate_random_z()
        is_state_B_updated = True

    if incoming_message.LoadFromPreset:
        print("Loading preset: ", incoming_message.value)
        bank = 0
        load_preset(args.presets_dir, bank, incoming_message.value)
        is_state_A_updated = True
        is_state_B_updated = True
        is_groove_updated = True

    if incoming_message.SaveToPreset:
        bank = 0
        save_preset(args.presets_dir, bank, incoming_message.value)

    return False

if __name__ == '__main__':
    # ------------------ Load Trained Model   ------------------ #
    model = VAEDrumGrooveTransformer(args.model_name, args.model_path)

    # ------------------ Load Message Manager  ------------------ #
    message_encoder = OutgoingMessageManager(uartMessagesJson="src/uartMessages.json")

    # --------------------   Latent Variable --------------------- #
    # These are saved in presets
    # the existing state of the module parameters are always kept in groove_state
    groove_state = LatentState(groove_steps=32)
    groove_state.latent_z = model.encode_into_latent_z(groove_state.groove.unscaled)
    state_A_latent_z = copy.deepcopy(groove_state.latent_z)
    state_B_latent_z = copy.deepcopy(groove_state.latent_z)
    playback_latent_z = copy.deepcopy(groove_state.latent_z)    # interpolated btn A/B/groove dep on slider/follow pots

    # ---------------------  UI State --------------------------------- #
    # the interpolation A, B and Groove states will be stored in playback_UI_state
    # used for gens, holds values that are either interpolated or adjusted by pots
    playback_UI_state = UIState()
    state_A_UI_state = None
    state_B_UI_state = None

    # ---------------- Parameters that Control Interpolation ---------------- #
    # 0 - 1: denotes how far along the interpolation slider we are
    existing_slider_position = None
    new_slider_position = None
    # 0 - 1: denotes how much we should interpolate between sliders position latent
    # and the latent of the groove we are following
    follow_amount_pot = None
    # variance_scaling_factor
    variance_scaling_factor_gp2 = 1.0

    # ------------------------- Flags ----------------------------- #
    clean_start = False
    is_groove_updated = False
    is_state_A_updated = False
    is_state_B_updated = False
    are_density_pots_updated = False
    is_slider_position_updated = False
    is_follow_amount_pot_updated = False
    is_temperature_pot_updated = False
    are_all_updated = False

    # the following is set to true if a CRASHAPP/ msg is received. This is used for debugging purposes
    # specifically to test whether the app automatically reruns after crashing
    shoulForceCrashAPPForDebuggin = False

    # ------------------  Synchronize with Seed  ------------------ #
    send_single_message_to_seed(message_encoder.SendAllParametersMessage)
    request_sent_time = time.time()

    while True:
        if __HAS_SERIAL__:
            while ser.in_waiting > 0:
                print("reading from serial")
                # get message from seed if there is one
                msg_ = get_message()
                if msg_ is not None:
                    if args.debug == 1:
                        print('msg_:', msg_.__dict__)
                    act_on_incoming_message(msg_)

            print("here ,", (not playback_UI_state.isReady()))
            # if the module is not ready after 10 seconds, send the message again
            if not playback_UI_state.isReady() and new_slider_position is None and follow_amount_pot is None:
                print("???????????? Requesting parameters again ???????????? ")
                send_single_message_to_seed(message_encoder.SendAllParametersMessage)
                if new_slider_position is not None:
                    existing_slider_position = new_slider_position
                if args.debug == 1:
                    print(f"!!!!! SYNCING playback_UI_state So FAR: \n {playback_UI_state.__dict__}")
                    print("new_slider_position: ", new_slider_position)
                time.sleep(5)
            elif playback_UI_state.isReady():
                if args.debug == 1:
                    print(f"!!!!! SYNCED playback_UI_state So FAR: \n\t {playback_UI_state}, \n\t {groove_state}")
                    print("Existing slider position: ", existing_slider_position)
                    print("New slider position: ", new_slider_position)
                # states A and B UI should be similar to existing if not loaded from a preset
                if state_A_UI_state is None or state_B_UI_state is None:
                    state_A_UI_state = copy.deepcopy(playback_UI_state)
                    state_B_UI_state = copy.deepcopy(playback_UI_state)
                break




    print(f"Module is ready \n\t\t, {groove_state}")
    # ------  Create an empty an empty torch tensor
    # ------  Create an empty h, v, o tuple for previously generated events to avoid duplicate messages
    (h, v, o, prob) = torch.zeros((1, 32, 9)), torch.zeros((1, 32, 9)), torch.zeros((1, 32, 9)), torch.zeros((1, 32, 9))

    while True:
        # ------  LOCAL FLAGS (Only updated below)  ------ #
        should_decode_latent_z = False
        should_resample_generation = False
        slider_change_amount = 0

        # -------------- Check if data is available from the serial port -------------- #
        while ser.in_waiting > 0:
            msg_ = get_message()
            if msg_ is not None:
                try:
                    if args.debug == 1:
                        print('msg_:', msg_)
                    shoulForceCrashAPPForDebuggin = act_on_incoming_message(msg_)
                    print("shoulForceCrashAPPForDebuggin; ", shoulForceCrashAPPForDebuggin)
                except:
                    print("Error in act_on_incoming_message")

            # if args.debug == 1:
            #     print(f"!!!!! NEW Groove_State: \n {groove_state}")
            #     print("new_slider_position: ", new_slider_position)

        if shoulForceCrashAPPForDebuggin:
            print("¡¡¡¡¡¡¡¡¡¡¡¡Forcing crash!!!!!!!!!!!")
            raise Exception("Forcing crash for debugging")

        if is_slider_position_updated:
            if existing_slider_position is None:
                existing_slider_position = new_slider_position

            else:
                slider_change_amount = new_slider_position - existing_slider_position
                existing_slider_position = new_slider_position

        if clean_start:
            groove_state.groove.clear()
            groove_state.latent_z = model.encode_into_latent_z(groove_state.groove.unscaled)
            state_A_latent_z = copy.deepcopy(groove_state.latent_z)
            state_B_latent_z = copy.deepcopy(groove_state.latent_z)
            # ---------------------  UI State --------------------------------- #
            state_A_UI_state = copy.deepcopy(playback_UI_state)
            state_B_UI_state = copy.deepcopy(playback_UI_state)
            are_all_updated = True

        if is_groove_updated or are_all_updated:
            # re-encode the groove into latent space
            groove_state.latent_z = model.encode_into_latent_z(groove_state.groove.scaled)
            should_decode_latent_z = True
        
        if is_state_A_updated or is_state_B_updated or are_all_updated:
            print("args.update_existing_state_after_AB_change: ", args.update_existing_state_after_AB_change)
            # re-encode the groove into latent space
            if args.update_existing_state_after_AB_change == 1:
                if existing_slider_position > .97:  # snap to state B
                    playback_latent_z = state_B_latent_z
                    playback_UI_state = copy.deepcopy(state_B_UI_state)
                elif existing_slider_position < .03:  # snap to state A
                    playback_latent_z = state_A_latent_z
                    playback_UI_state = copy.deepcopy(state_A_UI_state)
                else:
                    # recalulate the playback latent z using existing_slider_position (shouldn't be None by now)
                    #   and follow_amount_pot
                    playback_latent_z = state_A_latent_z + (state_B_latent_z - state_A_latent_z) * existing_slider_position
                    playback_latent_z = playback_latent_z + (groove_state.latent_z - playback_latent_z) * follow_amount_pot
                    # keep playback_UI_state the same unless following is uncommented

                    # # recalculate the playback UI state
                    # playback_UI_state = copy.deepcopy(state_A_UI_state)
                    # try:
                    #     playback_UI_state.interp_with(
                    #         distance_from_here=existing_slider_position,
                    #         end_of_path_state=state_B_UI_state,
                    #         allow_groove_velocity_gain_interp=interpolate_velocity_scale,
                    #         allow_groove_offset_quantization_interp=interpolate_offset_quantization,
                    #         allow_groove_inversion_interp=interpolate_groove_inversion)
                    # except:
                    #     print("Error in playback_UI_state.interp_with")
                    #     print("existing_slider_position: ", existing_slider_position)
                    #     print("state_A_UI_state: ", state_A_UI_state)
                    #     print("state_B_UI_state: ", state_B_UI_state)
                    #     print("playback_UI_state: ", playback_UI_state)
                    #     print("interpolate_velocity_scale: ", interpolate_velocity_scale)
                    #     print("interpolate_offset_quantization: ", interpolate_offset_quantization)
                    #     print("interpolate_groove_inversion: ", interpolate_groove_inversion)


            should_decode_latent_z = True

        if is_slider_position_updated or are_all_updated:
            # A. recalculate the playback latent z
            if existing_slider_position > .97:                  # snap to state B
                playback_latent_z = state_B_latent_z
            elif existing_slider_position < .03:                # snap to state A
                playback_latent_z = state_A_latent_z
            else:
                playback_latent_z = state_A_latent_z + (state_B_latent_z - state_A_latent_z) * existing_slider_position
            should_decode_latent_z = True
            # B. recalculate the playback UI state
            if existing_slider_position > .97:                  # snap to state B
                playback_UI_state = copy.deepcopy(state_B_UI_state)
            elif existing_slider_position < .03:                # snap to state A
                playback_UI_state = copy.deepcopy(state_A_UI_state)

        if is_follow_amount_pot_updated or is_groove_updated or are_all_updated:
            # only recalculate the playback latent z
            if follow_amount_pot > .97:  # snap to state B
                playback_latent_z = groove_state.latent_z
            elif follow_amount_pot < .03:  # keep the playback_latent_z as is (i.e. along A abd B)
                playback_latent_z = state_A_latent_z + (
                        state_B_latent_z - state_A_latent_z) * existing_slider_position
            else:
                playback_latent_z = state_A_latent_z + (
                        state_B_latent_z - state_A_latent_z) * existing_slider_position
                playback_latent_z = playback_latent_z + (
                        groove_state.latent_z - playback_latent_z) * follow_amount_pot
            should_decode_latent_z = True

        if should_decode_latent_z or is_temperature_pot_updated or are_density_pots_updated or are_all_updated:

            # get time of now
            if args.debug == 1:
                time_now1 = time.time()

            # decode the latent_z
            (h, v, o), prob = model.decode_latent_z(
                latent_z=playback_latent_z,
                inference_params=playback_UI_state.sampling_param_dict,
                sampling_mode=0)

            if args.debug == 1:
                print('[TIMING] Forward Pass Time: ', time.time() - time_now1)
                time_now2 = time.time()

            messages_to_send = message_encoder.getMessagesForGeneratedGroove(
                h_new=h,
                v_new=v,
                o_new=o,
                prob_new=prob,
                ignore_probs_below=0.01)

            send_single_message_to_seed(messages_to_send)

        # ------     RESET FLAGS (will be updated in act_on_incoming_message)    ------ #
        clean_start = False
        is_groove_updated = False
        is_state_A_updated = False
        is_state_B_updated = False
        are_density_pots_updated = False
        is_slider_position_updated = False
        is_follow_amount_pot_updated = False
        is_temperature_pot_updated = False
        are_all_updated = False

        time.sleep(args.wait)


