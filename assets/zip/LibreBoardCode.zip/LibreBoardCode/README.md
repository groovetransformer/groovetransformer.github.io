# Python Code Description

### src/states.py::LatentState && src/states.py::UIState
- LatentState holds the state of the module as well as A and B states. In this class, the state of 
UI parameters (UIState) is also held. These information will be used for interpolation and generations. Also, in this 
class, if needed, certain parameters can be set manually so as to be taken out of the interpolation process.
- All values in the UIState class are mapped to a range of 0 to 1, where 0 is the lowest values of a pot/slider and
1 is the maximum. **These values need to be mapped to generation level values before used for inference. 
See Below (src/StateMappers.py)**

### src/StateMappers.py::map_trigger_pots_to_thresholds_and_max_counts

```
map_trigger_pots_to_thresholds_and_max_counts(normalized_trigger_pots,
                                              force_max_kick_count=32, force_max_snare_count=32,
                                              force_max_chat_count=32, force_max_ohat_count=32,
                                              force_max_tom_count=32, force_max_crash_count=32,
                                              force_max_ride_count=32):
```
- Maps the values of the trigger pots (1-6) to thresholds and max counts for each voice.
- Assumes Crash and Ride are the 6th Voice and All three Toms are mixed in the 5th Voice.
- Can also force the max valuese to be something else than 32
- Trigger Pot Value of 0 --> Threshold of 0.99 and Max Count of 0 (or forced value)
- Trigger Pot Value of 1 --> Threshold of 0.05 and Max Count of 32 (or forced value)


### Groove Profile Mapping
![GrooveProfile.png](imgs%2FGrooveProfile.png)

- Groove Velocity == "Off" -> 0 or almost 0
- Groove Velocity == "Neutral" -> As is 
- Groove Velocity == "Max" -> Max possible gain

- Groove Inversion == "Off" -> No inversion (as is)
- Groove Inversion == "Flat" -> All same values
- Groove Inversion == "Full Invert" -> Fully Inverted Values

-----

# Encoding Messages

Messages of arbitrary length must be formatted as
    
    f"{ val||str }/{ val||str }/{ val||str }/..."


# List of Messages

### 1.Python2Seeed

#### Commands
1. `stale/`: notifies if nothing received from seeed in X seconds
2. `CRPT/`: notifies seeed if a message is corrupted or can not be interpreted



#### Generation Events
1. `NG/`: **N**ew **G**eneration Coming Soon
2. `H/{voice}/{step}/{vel}/{off}` --> Full info about a hit, if sampling done in Python --> vel 0 to 127 int, offset in -0.5 to 0.5
3. `P/{voice}/{step}/{Probability}/{vel}/{off}` --> Non-zero Probabilities to be used for sampling in Seeed
4. `GD/`: **G**eneration **Done**

### 1.Seed2Py
----
1. `G/{step}/{vel}/{off}`  --> vel 0 to 127 int and offset -500 to 500

## GPIO UART
/dev/ttyAML6 for GPIO UART --> https://hub.libre.computer/t/how-to-enable-uart-a-and-921600-baud-rate-for-aml-s805x-ac-and-aml-s905x-cc/166

    sudo ldto enable uart-a
    sudo ln -s /dev/ttyAML6
