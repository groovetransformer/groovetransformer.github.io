import torch
import os
from src.helpers.VAE.modelLoader import load_variational_mgt_model
import numpy as np

class VAEDrumGrooveTransformer:
    def __init__(self, model_name, model_path):
        self.__model = load_variational_mgt_model(os.path.join(model_path, model_name))
        self.__model.eval()
        self.__latent_dim = self.__model.latent_dim

    def encode_into_latent_z(self, in_groove):
        """
        returns Z corresponding to a provided groove of shape (1, 32, 3)
        """
        if not isinstance(in_groove, torch.Tensor):
            in_groove = torch.tensor(in_groove, dtype=torch.float32)

        # Generation using an Input Groove
        # Step 1. Get the mean and var of the latent encoding
        mu, logvar = self.__model.encode_to_mu_logvar(in_groove)

        # Step 2. Sample a latent vector (z) from latent distribution
        latent_z = self.__model.reparametrize(mu, logvar)

        return latent_z

    def decode_latent_z(self, latent_z, inference_params, sampling_mode=0):
        """ returns a full drum pattern based on a provided latent encoding Z
        """
        voice_thresholds_ = inference_params["nine_voices_thesholds"]
        voice_max_count_allowed_ = inference_params["nine_voices_max_counts"]
        temperature_ = inference_params["temperature"]

        if temperature_ > 0.5:
            temperature_ = (temperature_ - 0.5) * 3
        else:
            temperature_ = temperature_ * 2

        if not isinstance(latent_z, torch.Tensor):
            latent_z = torch.tensor(latent_z, dtype=torch.float32)

        def torch_tempered_sigmoid(x, t=1.0):
            return 1.0 / (1.0 + torch.exp(-x / t))

        with torch.no_grad():
            h_logits, v_logits, o_logits = self.__model.Decoder.forward(latent_z)
            tempered_probs = torch_tempered_sigmoid(h_logits, t=temperature_)

            h = torch.zeros_like(tempered_probs)

            v = torch.sigmoid(v_logits)

            if self.__model.o_activation == "tanh":
                o = torch.tanh(o_logits) * 0.5
            elif self.__model.o_activation == "sigmoid":
                o = torch.sigmoid(o_logits) - 0.5
            else:
                raise ValueError(f"{self.__model.o_activation} for offsets is not supported")

            if sampling_mode == 0:
                for ix, (thres, max_count) in enumerate(zip(voice_thresholds_, voice_max_count_allowed_)):
                    max_indices = torch.topk(tempered_probs[:, :, ix], max_count).indices[0]
                    h[:, max_indices, ix] = tempered_probs[:, max_indices, ix]
                    h[:, :, ix] = torch.where(h[:, :, ix] > thres, 1, 0)
            elif sampling_mode == 1:
                for ix, (thres, max_count) in enumerate(zip(voice_thresholds_, voice_max_count_allowed_)):
                    # sample using probability distribution of hits (_h)
                    voice_probs = tempered_probs[:, :, ix]
                    sampled_indices = torch.bernoulli(voice_probs)
                    max_indices = torch.topk(sampled_indices * voice_probs, max_count).indices[0]
                    h[:, max_indices, ix] = 1

            # sample using probability distribution of velocities (v)
            return (h, v, o), tempered_probs

    def generate_from_groove(self, in_groove, inference_params, sampling_mode=0):
        """ returns a full drum pattern based on the provided input groove
        """
        inference_params["latent_z"] = self.encode_into_latent_z(in_groove)
        return self.decode_latent_z(inference_params, sampling_mode), inference_params["latent_z"]

    def generate_random_z(self, scale_variance=1.0):
        """ returns a random latent vector Z """
        return torch.normal(torch.zeros(self.__latent_dim), torch.ones(self.__latent_dim) * scale_variance)


if __name__ == "__main__":
    # Test
    model_path = "src/model/VAE/trained"
    model_name = "100.pth"

    model = VAEDrumGrooveTransformer(model_name, model_path)

    from src.Groove import InputGroove

    h = np.random.randint(0, 2, 32)
    v = np.random.rand(32) * h
    o = (np.random.rand(32) - 0.5) * h
    g = np.stack((h, v, o)).transpose()

    input_groove = InputGroove(original_groove=g)
    input_groove.set_vel_change_amount(0)
    input_groove.set_inversion_amount(0)

    l_z = model.encode_into_latent_z(input_groove.scaled)
    print(l_z.shape)

    # Test generation
    voice_thresholds = [0.5] * 9
    voice_max_count_allowed = [32] * 9

    (h, v, o), tempered_probs = model.generate_from_groove(
        in_groove=input_groove.scaled,
        voice_thresholds_=voice_thresholds,
        voice_max_count_allowed_=voice_max_count_allowed,
        temperature_=1.0,
    )
    print(h)

    # Test random generation
    random_z = model.generate_random_z()
    (h, v, o), tempered_probs = model.decode_latent_z(
        latent_z=random_z,
        voice_thresholds_=voice_thresholds,
        voice_max_count_allowed_=voice_max_count_allowed,
        temperature_=1.0,
    )
    print(h)

