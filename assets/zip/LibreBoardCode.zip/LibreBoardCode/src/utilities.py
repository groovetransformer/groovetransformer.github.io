# Import model
import torch
from src.helpers.VAE.modelLoader import load_variational_mgt_model
import os
import numpy as np
import time
import src.ModelAPI as ModelAPI
import threading

# MAGENTA MAPPING
ROLAND_REDUCED_MAPPING = {
    "KICK": [36],
    "SNARE": [38, 37, 40],
    "HH_CLOSED": [42, 22, 44],
    "HH_OPEN": [46, 26],
    "TOM_3_LO": [43, 58],
    "TOM_2_MID": [47, 45],
    "TOM_1_HI": [50, 48],
    "CRASH": [49, 52, 55, 57],
    "RIDE":  [51, 53, 59]
}
ROLAND_REDUCED_MAPPING_VOICES = ['/KICK', '/SNARE', '/HH_CLOSED', '/HH_OPEN', '/TOM_3_LO', '/TOM_2_MID', '/TOM_1_HI', '/CRASH', '/RIDE']


def encode_list_as_message(list_of_vals, nDecimals=2):
    l_ = list()
    for val in list_of_vals:
        if isinstance(val, float):
            val = np.round(val, nDecimals)
        l_.append(str(val))
    return "/".join(l_)


def get_messages_for_daisey(v_new, o_new, h_new, prob_new,
                            ignore_probs_below=0.01, prepend_NG=True, append_GD=True,
                            send_hits=True, send_probs=False):
    """
    :param v_new: (batch, time, voice) tensor of velocities
    :param o_new: (batch, time, voice) tensor of offsets
    :param h_new: (batch, time, voice) tensor of hits
    :param prob_new: (batch, time, voice) tensor of hit probabilities
    :param ignore_probs_below: ignore hits with probabilities below this value
    :param prepend_NG: prepend a "NG/" (NewGeneration) message to the beginning of the message list
    :param append_GD: append a "GD/" (GenerationDone) message to the end of the message list

    :return: str of messages to be sent to daisy
                - formatted as "hit"/{voice_ix}/{timestep}/{velocity}/{offset} --> if h_new is provided
                - formatted as "prob"/{voice_ix}/{timestep}/{probability}/{velocity}/{offset} --> if prob_new is given
    """

    if prepend_NG:
        message_list = 'NG/\n'
    else:
        message_list = ''

    # set v_new to 0 if it is below .01
    v_new[v_new < 0.1] = 0.0

    # set h and prob to zero where v_new is zero
    if h_new is not None:
        h_new[v_new == 0.0] = 0.0

    if prob_new is not None:
        prob_new[v_new == 0.0] = 0.0

    if send_hits is not None:
        hit_locations_new = torch.nonzero(h_new)

        for batch_ix, timestep, voiceIx in hit_locations_new:
            msg = encode_list_as_message(['H',
                                          voiceIx.item(),
                                          timestep.item(),
                                          int(v_new[batch_ix, timestep, voiceIx].item() * 127),
                                          o_new[batch_ix, timestep, voiceIx].item()
                                          ])
            message_list += (msg+'\n')

    if send_probs is not None:
        # set prob_new values to 0 if they are below a threshold
        prob_new[prob_new < ignore_probs_below] = 0.0

        prob_locations_new = torch.nonzero(prob_new)

        for batch_ix, timestep, voiceIx in prob_locations_new:
            msg = encode_list_as_message(['P',
                                          voiceIx.item(),
                                          timestep.item(),
                                          prob_new[batch_ix, timestep, voiceIx].item(),
                                          int(v_new[batch_ix, timestep, voiceIx].item() * 127),
                                          o_new[batch_ix, timestep, voiceIx].item()
                                          ])

            message_list += (msg+'\n')

    if append_GD:
        message_list += 'GD/\n'

    return message_list