import os
import pickle
import logging
import numpy as np
from src.Groove import InputGroove

logging.basicConfig(level=logging.INFO)

logger = logging.getLogger("src/State.py")


def map_trigger_pots_to_thresholds_and_max_counts(normalized_trigger_pots,
                                                  force_max_kick_count=32, force_max_snare_count=32,
                                                  force_max_chat_count=32, force_max_ohat_count=32,
                                                  force_max_tom_count=32, force_max_crash_count=32,
                                                  force_max_ride_count=32):
    """
    Maps the trigger pots to the thresholds used to sample the model

    - Normalized Trigger Pot Value of 0 --> Threshold of 0.99 and Max Count of 0 (or forced value)
    - Normalized Trigger Pot Value of 1 --> Threshold of 0.05 and Max Count of 32 (or forced value)

    Args:
        normalized_trigger_pots (list of floats): list of the values of the trigger pots normalized between 0 and 1
        force_max_kick_count (int): max number of kick notes allowed
        force_max_snare_count (int): max number of snare notes allowed
        force_max_chat_count (int): max number of closed hihat notes allowed
        force_max_ohat_count (int): max number of open hihat notes allowed
        force_max_tom_count (int): max number of tom notes allowed
        force_max_crash_count (int): max number of crash notes allowed
        force_max_ride_count (int): max number of ride notes allowed

    Returns:
        nine_voices_sampling_thresholds (numpy array of floats): list of the thresholds used to sample the model
        nine_voices_max_counts (numpy array of ints): list of the max counts used to sample the model

    """

    assert len(normalized_trigger_pots) == 6, \
        f"Trigger pots must be a list of 6 values, not {len(normalized_trigger_pots)}"

    nine_voices_sampling_thresholds = [0] * 9
    nine_voices_max_counts = [0] * 9

    # Kick
    nine_voices_sampling_thresholds[0] = round(max(min(0.99, 1.0 - normalized_trigger_pots[0]), 0.05), 2)
    print(normalized_trigger_pots, force_max_kick_count)
    nine_voices_max_counts[0] = min(int(32 * normalized_trigger_pots[0]), force_max_kick_count)

    # Snare
    nine_voices_sampling_thresholds[1] = round(max(min(0.99, 1.0 - normalized_trigger_pots[1]), 0.05), 2)
    nine_voices_max_counts[1] = min(int(32 * normalized_trigger_pots[1]), force_max_snare_count)

    # Closed HiHat
    nine_voices_sampling_thresholds[2] = round(max(min(0.99, 1.0 - normalized_trigger_pots[2]), 0.05), 2)
    nine_voices_max_counts[2] = min(int(32 * normalized_trigger_pots[2]), force_max_chat_count)

    # Open HiHat
    nine_voices_sampling_thresholds[3] = round(max(min(0.99, 1.0 - normalized_trigger_pots[3]), 0.05), 2)
    nine_voices_max_counts[3] = min(int(32 * normalized_trigger_pots[3]), force_max_ohat_count)

    # low, mid, high tom
    nine_voices_sampling_thresholds[4] = round(max(min(0.99, 1.0 - normalized_trigger_pots[4]), 0.05), 2)
    nine_voices_max_counts[4] = min(int(32 * normalized_trigger_pots[4]), force_max_tom_count)
    nine_voices_sampling_thresholds[5] = nine_voices_sampling_thresholds[4]
    nine_voices_max_counts[5] = nine_voices_max_counts[4]
    nine_voices_sampling_thresholds[6] = nine_voices_sampling_thresholds[4]
    nine_voices_max_counts[6] = nine_voices_max_counts[4]

    # Crash
    nine_voices_sampling_thresholds[7] = round(max(min(0.99, 1.0 - normalized_trigger_pots[5]), 0.05), 2)
    nine_voices_max_counts[7] = min(int(32 * normalized_trigger_pots[5]), force_max_crash_count)

    # Ride
    nine_voices_sampling_thresholds[8] = round(max(min(0.99, 1.0 - normalized_trigger_pots[5]), 0.05), 2)
    nine_voices_max_counts[8] = min(int(32 * normalized_trigger_pots[5]), force_max_ride_count)

    return nine_voices_sampling_thresholds, nine_voices_max_counts


class UIState:
    """
    This class contains the state of the UI. It can be used to save the state of the UI at any given time or to
    load the state of the UI from a previous session.

    Values are received as Pot Levels (0-1) and are stored as normalized values (0.0-1.0)

    Attributes:
        __trigger_pots (numpy array of ints): list of the values of the trigger pots
        __temperature (float):
        __groove_velocity_gain (float):
        __groove_offset_quantization (int):
        __general_purpose_pots (numpy array of ints): list of the values of the general purpose pots
        __groove_inversion (int): mapped to general purpose pot 1

    """
    def __init__(self):
        self.__trigger_pots = np.array([np.nan] * 6)
        self.__temperature = np.nan
        self.__groove_velocity_gain = np.nan
        self.__groove_offset_quantization = np.nan
        self.__general_purpose_pots = np.array([np.nan] * 3)
        self.__groove_inversion = np.nan    # mapped to general purpose pot 1
        self.__groove_params_dict = None  # to be calculated only once when relevant pots are changed
        self.__sampling_param_dict = None  # to be calculated only once when relevant pots are changed

    def isReady(self):
        return not np.isnan(self.__temperature) and \
            not np.isnan(self.__groove_velocity_gain) and \
            not np.isnan(self.__groove_offset_quantization) and \
               not np.isnan(self.__trigger_pots).any() and \
            not np.isnan(self.__general_purpose_pots).any() and \
            not np.isnan(self.__groove_inversion)

    @ property
    def trigger_pots(self):
        return self.__trigger_pots

    @trigger_pots.setter
    def trigger_pots(self, trigger_pots):
        self.__trigger_pots = trigger_pots
        self.__sampling_param_dict = None

    @property
    def temperature(self):
        return self.__temperature

    @temperature.setter
    def temperature(self, temperature):
        self.__temperature = temperature
        self.__sampling_param_dict = None

    @property
    def groove_velocity_gain(self):
        return self.__groove_velocity_gain

    @groove_velocity_gain.setter
    def groove_velocity_gain(self, groove_velocity_gain):
        self.__groove_velocity_gain = groove_velocity_gain
        self.__groove_params_dict = None

    @property
    def groove_offset_quantization(self):
        return self.__groove_offset_quantization

    @groove_offset_quantization.setter
    def groove_offset_quantization(self, groove_offset_quantization):
        self.__groove_offset_quantization = groove_offset_quantization
        self.__groove_params_dict = None

    @property
    def general_purpose_pots(self):
        return self.__general_purpose_pots

    @general_purpose_pots.setter
    def general_purpose_pots(self, general_purpose_pots):
        self.__general_purpose_pots = general_purpose_pots
        self.__groove_inversion = general_purpose_pots[0]
        self.__groove_params_dict = None

    @property
    def groove_inversion(self):
        return self.__groove_inversion

    @groove_inversion.setter
    def groove_inversion(self, groove_inversion):
        self.__groove_inversion = groove_inversion
        self.__general_purpose_pots[0] = groove_inversion
        self.__groove_params_dict = None

    @property
    def groove_params_dict(self):
        self.__groove_params_dict = dict()
        self.__groove_params_dict["velocity_gain"] = self.groove_velocity_gain
        self.__groove_params_dict["offset_quantization"] = self.groove_offset_quantization
        self.__groove_params_dict["groove_inversion"] = self.groove_inversion
        return self.__groove_params_dict

    @property
    def sampling_param_dict(self):
        self.__sampling_param_dict = dict()
        theshs_, cnts_ = map_trigger_pots_to_thresholds_and_max_counts(self.trigger_pots)
        self.__sampling_param_dict["nine_voices_thesholds"] = theshs_
        self.__sampling_param_dict["nine_voices_max_counts"] = cnts_
        if self.temperature < 0.5:
            self.__sampling_param_dict["temperature"] = self.temperature * 2
        else:
            self.__sampling_param_dict["temperature"] = (self.temperature - 0.5) * 2

        return self.__sampling_param_dict

    # ------------------ PICKLING METHODS ------------------
    # def __getstate__(self):
    #     # no need to pickle the per_voice_sampling_thresholds and per_voice_max_counts
    #     return self.__dict__
    #
    # def __setstate__(self, state):
    #     for key in state.keys():
    #         if key in self.__dict__.keys():
    #             self.__dict__[key] = state[key]
    #         else:
    #             logger.info(f"  Key {key} not found in UIState")

    def __repr__(self):
        return f"[STATE.py]: UIState(\n\t\tGroove Params = {self.groove_params_dict}, " \
               f"\n\t\tSampling Params = {self.sampling_param_dict})"

    # ------------------ External Setters ------------------
    def force_set_state(self, trigger_pots=None, temperature=None, groove_velocity_gain=None,
                        groove_offset_quantization=None, general_purpose_pots=None):
        """
        sets the state of the UI. If you want something to be unchanged, just don't pass it as a parameter

        **NOTE** You can use this to set a specific state parameter after interpolation between two states

        :param trigger_pots: (numpy array of ints) list of the values of the trigger pots
        :param temperature: (float) temperature of the model (from 0.0 to 3.0) where 0 is deterministic and 3 is random
                            and 1 is the default
                            Knob value 0 -> 0.0, knob value 1 -> 3.0, knob value 50 -> 1.0
        :param groove_velocity_gain: (float) gain of the velocity of the groove (from 0.0 to 3.0)
                            knob value 0 -> 0.0, knob value 1 -> 3.0, knob value 50 -> 1.0
        :param groove_offset_quantization: (int) quantization of the groove offset (from 0 to 1)
                            knob value 0 -> 1 (no quantization), knob value 1 -> 0 (quantize to 1/16th notes)
        :param general_purpose_pots: (numpy array of ints) list of the values of the general purpose pots
        :return: None
        """

        if trigger_pots is not None:
            assert len(trigger_pots) == 6, "trigger_pots must be a list of 6 values"
            for v in trigger_pots:
                assert 0 <= v <= 1, "trigger_pots values must be between 0 and 1"
            if isinstance(trigger_pots, list):
                trigger_pots = np.array(trigger_pots)
            self.__trigger_pots = trigger_pots 

        if temperature is not None:
            assert 0 <= temperature <= 1, "temperature must be between 0 and 1"
            self.__temperature = temperature / 1

        if groove_velocity_gain is not None:
            assert 0 <= groove_velocity_gain <= 1, "groove_velocity_gain must be between 0 and 1"
            self.__groove_velocity_gain = groove_velocity_gain / 1

        if groove_offset_quantization is not None:
            assert 0 <= groove_offset_quantization <= 1, "groove_offset_quantization must be between 0 and 1"
            self.__groove_offset_quantization = groove_offset_quantization / 1

        if general_purpose_pots is not None:
            assert len(general_purpose_pots) == 3, "general_purpose_pots must be a list of 3 values"
            if isinstance(general_purpose_pots, list):
                general_purpose_pots = np.array(general_purpose_pots)
            for v in general_purpose_pots:
                assert 0 <= v <= 1, "general_purpose_pots values must be between 0 and 1"
            self.__general_purpose_pots = general_purpose_pots / 1

    # ------------------ External Getters ------------------
    def get_state(self):
        """
        returns the state of the UI

        :return: (dict) the state of the UI
        """
        return {
            "trigger_pots": self.__trigger_pots,
            "temperature": self.__temperature,
            "groove_velocity_gain": self.__groove_velocity_gain,
            "groove_offset_quantization": self.__groove_offset_quantization,
            "general_purpose_pots": self.__general_purpose_pots,
            "groove_inversion": self.__groove_inversion,
        }

    def get_actual_pot_values(self):
        """
        returns the actual values of the pots (not the knob values)

        :return: (numpy array of ints) the actual values of the pots
        """

        res = {
            "trigger_pots": [int(v) for v in self.__trigger_pots],
            "randomness": int(self.__temperature),
            "groove_velocity_gain": int(self.__groove_velocity_gain),
            "groove_offset_quantization": int(self.__groove_offset_quantization),
            "general_purpose_pots": [int(v) for v in self.__general_purpose_pots]
        }

        return res

    # ------------------ Interpolation Methods ------------------
    def interp_with(
            self, distance_from_here, end_of_path_state, allow_groove_velocity_gain_interp=False,
            allow_groove_offset_quantization_interp=False, allow_groove_inversion_interp=False):
        """
        moves the interpolable parameters (trigger_pots and temperature) of the UI state by a certain distance


        :param distance_from_here: (float) value from 0-1 representing the distance from current state
                        0 means current state, 1 means end of path state
        :param end_of_path_state:  (UIState) the state at the end of the path
        :param allow_groove_velocity_gain_interp: (bool) whether to allow interpolation of groove_velocity_gain
        :param allow_groove_offset_quantization_interp: (bool) whether to allow interp of groove_offset_quantization
        :param allow_groove_inversion_interp: (bool) whether to allow interpolation of groove_inversion
        :return: None
        """
        assert 0 <= distance_from_here <= 1, "distance_from_here must be between 0 and 1"

        end_path_state_dict = end_of_path_state.get_state()

        self.__trigger_pots = self.__trigger_pots + (np.array(end_path_state_dict["trigger_pots"]) -
                                                     np.array(self.__trigger_pots)) * distance_from_here
        self.__temperature = self.__temperature + (end_path_state_dict["temperature"] - self.__temperature) * \
                             distance_from_here

        if allow_groove_velocity_gain_interp:
            self.__groove_velocity_gain = self.__groove_velocity_gain + \
                                          (end_path_state_dict["groove_velocity_gain"] - self.__groove_velocity_gain) * \
                                          distance_from_here
        if allow_groove_offset_quantization_interp:
            self.__groove_offset_quantization = self.__groove_offset_quantization + \
                                                (end_path_state_dict["groove_offset_quantization"] -
                                                 self.__groove_offset_quantization) * distance_from_here
        if allow_groove_inversion_interp:
            self.__groove_inversion = self.__groove_inversion + \
                                      (end_path_state_dict["groove_inversion"] - self.__groove_inversion) * \
                                      distance_from_here

class LatentState:
    def __init__(self, starting_groove=None, groove_steps=None):
        self.latent_z = None
        # Following are only calculated once whenever needed and if haven't been calculated before
        self.groove = None if starting_groove is None and groove_steps is None else \
            InputGroove(original_groove=starting_groove, num_steps=groove_steps)

    def pickle(self, path, filename):
        os.makedirs(path, exist_ok=True)
        with open(os.path.join(path, f'{filename}.MdlState'), 'wb') as f:
            pickle.dump(self, f)

    def move_by_interpolation(self, distance_from_here, end_of_path_state,
                              force_set_trigger_pots=None, force_set_temperature=None,
                              force_set_groove_velocity_gain=None, force_set_groove_offset_quantization=None,
                              force_set_general_purpose_pots=None):
        """
        moves the state of the module by interpolating the latent vector and the UI state
        """
        assert 0 <= distance_from_here <= 1, "distance_from_here must be between 0 and 1"

        assert self.latent_z is not None or end_of_path_state.latent_z is None, \
            "end_of_path_state.latent_z must be None if you want to interpolate the latent_z"

        if self.latent_z is not None:   # if latent_z is None, we are using interpolation only for the UI state
            assert end_of_path_state.latent_z is not None, "end_of_path_state.latent_z must not be None if you" \
                                                           "want to interpolate the latent_z"

            # move latent_z towards the end_of_path_state by distance_from_here
            self.latent_z = self.latent_z + (end_of_path_state.latent_z - self.latent_z) * distance_from_here

    def __repr__(self):
        return f"++++++++++++++++++++++++++++++STATE.py++++++++++++++++++++++++++++++" \
               f"LatentState(\n\tlatent_z[:10]={self.latent_z[0][:10] if self.latent_z is not None else 'None'}," \
               f"\n\tgroove[:10] = {self.groove if self.groove is not None else 'NO GROOVE REGISTERED TO STATE'}" \
               f"---------------------------------------------------------------------"