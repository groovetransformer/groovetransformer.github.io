import numpy as np
import torch

try:
    from bokeh.plotting import figure, output_file, show, save
    from bokeh.models import ColumnDataSource, Range1d, Label,Panel, Tabs
    from bokeh.io import output_notebook, output_file
    __HAS_BOKEH__ = True
    output_file("test.html")
except:
    __HAS_BOKEH__ = False


def adjust_groove(groove_vel_profile, vel_change_amount, inversion_amount):
    """
    Adjust the groove velocity profile by scaling and inverting it
    :param groove_vel_profile: (np.array) velocity profile of the groove
    :param vel_change_amount: <0 makes the groove quieter, >0 makes it louder, 0 is no change
    :param inversion_amount: 0 is no change, 1 is flat profile, 2 is fully inverted profile
    :return:
    """

    def sigmoid(x):
        return 1 / (1 + np.exp(-x))

    def scale_profile(vel, vel_change_amount, clip_range=None):
        # amount = 0 -> no change. >0 increases the values, <0 reduces the values

        new_vals = vel + vel_change_amount * sigmoid(vel)
        if clip_range is not None:
            new_vals = np.clip(new_vals, clip_range[0], clip_range[1])

        return new_vals

    def invert_profile(vel, inversion_amount):
        # amount = 0 -> no change. amount = 1 -> flat profile, amount = 2 -> inverted profile
        # interpolate between vel and 1-vel
        direction = 0.5 - vel
        return vel + direction * inversion_amount

    inverted_profile = invert_profile(groove_vel_profile, inversion_amount)
    scaled_inverted_profile = scale_profile(inverted_profile, vel_change_amount, clip_range=[0, 1])

    return scaled_inverted_profile


class InputGroove:
    """
    A class to represent a groove that is being input into the system

    Attributes
    ----------
    original_groove : np.array
        The original groove that is recorded from the user
    adjusted_groove : np.array
        The adjusted groove that is being input into the system
    vel_change_amount : float
        The amount to scale the velocity profile by (0 is no change, >0 increases the values, <0 reduces the values)
    inversion_amount : float (between 0 and 2)
        The amount to invert the velocity profile by (0 is no change, 1 is flat profile, 2 is fully inverted profile)

    """
    def __init__(self, original_groove=None, num_steps=None):
        assert original_groove is not None or num_steps is not None, "Must provide either original_groove or num_steps"
        self.__original_groove = np.zeros((num_steps, 3)) if original_groove is None else original_groove
        self.__adjusted_groove = None
        self.__vel_change_amount = 0
        self.__inversion_amount = 0
        self.__offset_quantization = 0

    @property
    def unscaled(self):
        return self.__original_groove

    @property
    def scaled(self):
        assert self.__vel_change_amount is not None, "Must set vel_change_amount before getting scaled groove"
        assert self.__inversion_amount is not None, "Must set inversion_amount before getting scaled groove"

        if self.__adjusted_groove is None:
            self.__adjusted_groove = np.copy(self.__original_groove)
            # adjust the velocity of groove
            self.__adjusted_groove[:, 1] = adjust_groove(
                self.__original_groove[:, 1], self.__vel_change_amount, self.__inversion_amount) * \
                                           self.__original_groove[:, 0]

            # adjust the offset of the groove
            self.__adjusted_groove[:, 2] = self.__adjusted_groove[:, 2] * (1-self.__offset_quantization)

        return self.__adjusted_groove

    def extract_input_groove_from_drum_pattern(self, h, v, o):
        """
        Extract the input groove from a drum pattern
        :param h, v, o:  (Tensor) hit profile of the drum pattern shape=(batch_size, num_steps, num_drums)
        :return:
        """
        self.__adjusted_groove = None

        self.__original_groove = np.zeros((h.shape[1], 3))
        for i in range(h.shape[1]):
            # see if any hits at time step i
            if (h[0, i, :] == 1).any():
                # get the max velocity and index of max velocity
                max_vel = torch.max(v[0, i, :]).item()
                max_vel_idx = torch.argmax(v[0, i, :]).item()
                offset = o[0, i, max_vel_idx].item()
                self.add_event(i, max_vel, offset)

    def add_event(self, timestep, velocity, offset):
        self.__original_groove[timestep, 0] = 1 if velocity > 0 else 0
        self.__original_groove[timestep, 1] = velocity if velocity > 0 else 0
        self.__original_groove[timestep, 2] = offset if velocity > 0 else 0
        self.__adjusted_groove = None

    def set_vel_change_amount(self, amount):
        print("[InputGroove] Setting amount to map from {}".format(amount))
        # assumes amount is between 0 and 1 (normalized pot value)
        if amount == 0.5:
            print("[InputGroove] Setting vel_change_amount to 0")
            self.__vel_change_amount = 0
        elif amount > 0.5:
            self.__vel_change_amount = 2 * (amount - 0.5)
            print("[InputGroove] Setting vel_change_amount to {}".format(self.__vel_change_amount))
        else:
            self.__vel_change_amount = -2 * (0.5 - amount)
            print("[InputGroove] Setting vel_change_amount to {}".format(self.__vel_change_amount))

        self.__vel_change_amount = amount
        self.__adjusted_groove = None

    def set_inversion_amount(self, amount):
        # assumes amount is between 0 and 1 (normalized pot value)
        self.__inversion_amount = amount * 2
        self.__adjusted_groove = None

    def set_offset_quantization(self, quantization):
        # assumes amount is between 0 and 1 (normalized pot value)
        self.__offset_quantization = quantization
        self.__adjusted_groove = None

    def clear(self):
        self.__original_groove = np.zeros_like(self.__original_groove)
        self.__adjusted_groove = None

    def __repr__(self):
        uscal_ = np.copy(self.unscaled)
        groove_unscaled = ["{:.1f}".format(v) for v in uscal_[:, 1]]
        scal_ = np.copy(self.scaled)
        groove_scaled = ["{:.1f}".format(v) for v in scal_[:, 1]]

        return f"InputGroove(\n" \
               f"unscaled[:10]=\n{groove_unscaled[:10]},\n" \
                f"scaled[:10]=\n{groove_scaled[:10]},\n" \
               f"vel_change_amount={self.__vel_change_amount}, inversion_amount={self.__inversion_amount}), " \
               f"offset_quantization={self.__offset_quantization})"

    def plot_groove(self):
        if not __HAS_BOKEH__:
            print("Bokeh not installed, cannot plot groove")
            return

        # plot the groove
        original = figure(plot_width=800, plot_height=400, title="Groove")
        original.scatter(range(len(self.unscaled)), self.unscaled[:, 1], line_width=2, color="blue", alpha=0.5)
        original.vbar(x=range(len(self.unscaled)), width=0.01, bottom=0, top=self.unscaled[:, 1], color="blue", alpha=0.5)

        adjusted = figure(plot_width=800, plot_height=400, title="Adjusted Groove")
        adjusted.scatter(range(len(self.scaled)), self.scaled[:, 1], line_width=2, color="red", alpha=0.5)
        adjusted.vbar(x=range(len(self.scaled)), width=0.01, bottom=0, top=self.scaled[:, 1], color="red", alpha=0.5)

        return Tabs(tabs=[Panel(child=original, title="Original"), Panel(child=adjusted, title="Adjusted")])


if __name__ == "__main__":
    h = np.random.randint(0, 2, 32)
    v = np.random.rand(32) * h
    o = (np.random.rand(32) - 0.5) * h
    g = np.stack((h, v, o)).transpose()

    input_groove = InputGroove(original_groove=g)
    input_groove.set_vel_change_amount(1)
    input_groove.set_inversion_amount(2)
    print(input_groove.scaled.shape)
    print(input_groove.scaled)

    if __HAS_BOKEH__:
        show(input_groove.plot_groove())