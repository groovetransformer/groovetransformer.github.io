import json
import numpy as np
import torch


def encode_list_as_message(list_of_vals, nDecimals=2):
    l_ = list()
    for val in list_of_vals:
        if isinstance(val, float):
            val = np.round(val, nDecimals)
        l_.append(str(val))
    return "/".join(l_)


class OutgoingMessageManager:
    def __init__(self, uartMessagesJson):
        with open(uartMessagesJson) as f:
            self.__uartMessages = json.load(f)["Outgoing"]

    @property
    def uartMessages(self):
        return self.__uartMessages

    def getMessagesForGeneratedGroove(self, h_new, v_new, o_new, prob_new, ignore_probs_below=0.01):
        """
        :param v_new: (batch, time, voice) tensor of velocities
        :param o_new: (batch, time, voice) tensor of offsets
        :param h_new: (batch, time, voice) tensor of hits
        :param prob_new: (batch, time, voice) tensor of hit probabilities
        :param ignore_probs_below: ignore hits with probabilities below this value

        :return: str of messages to be sent to daisy (see formatting in uartMessages.json)
        """
        message_list = ''

        settings = self.uartMessages["Generations"]
        if settings["signalStart"]:
            message_list = f'{settings["start"]}\n'

        # set v_new to 0 if it is below .01
        v_new[v_new < 0.05] = 0.0

        # set h and prob to zero where v_new is zero
        if h_new is not None:
            h_new[v_new == 0.0] = 0.0

        if prob_new is not None:
            prob_new[v_new == 0.0] = 0.0

        if settings["sendHits"]:
            hit_locations_new = torch.nonzero(h_new)

            for _, timestep, voiceIx in hit_locations_new:
                msg = settings["Hit"].replace("{voice}", settings["VoiceMapping"][str(voiceIx.item())]).replace(
                    "{step}", str(timestep.item()))
                msg = msg.replace("{vel}", str(int(v_new[0, timestep, voiceIx].item() * settings["MaxVel"])))
                msg = msg.replace("{off}", str(np.round(
                    o_new[0, timestep, voiceIx].item() * settings["MaxOffset"] / 0.5, 2)))
                message_list += (msg+'\n')

        if settings["sendProbabilities"]:
            #
            # prob_new[prob_new < ignore_probs_below] = 0.0
            #
            # prob_locations_new = torch.nonzero(prob_new)
            #
            # for batch_ix, timestep, voiceIx in prob_locations_new:
            #     msg = settings["Probability"].replace("{voice}", settings["VoiceMapping"][str(voiceIx.item())]).replace(
            #         "{step}", str(timestep.item()))
            #     msg = msg.replace("{Probability}", str(np.round(
            #         prob_new[batch_ix, timestep, voiceIx].item(), 2)))
            #     msg = msg.replace(
            #         "{vel}", str(int(v_new[batch_ix, timestep, voiceIx].item() * settings["MaxVel"])))
            #     msg = msg.replace("{off}", str(np.round(
            #         o_new[batch_ix, timestep, voiceIx].item() * settings["MaxOffset"] / 0.5, 2)))
            #
            #     message_list += (msg+'\n')
            pass

        if settings["signalEnd"]:
            message_list += f'{settings["end"]}\n'

        return message_list

    @property
    def SendAllParametersMessage(self):
        return self.uartMessages["Requests"]["SendAllParameters"]

    @property
    def StaleMessage(self):
        return self.uartMessages["Requests"]["Stale"]

    @property
    def CorruptedMessage(self):
        return self.uartMessages["Requests"]["CorruptedMessage"]


class IncomingMessage:
    def __init__(self, message, uartMessagesJson):
        with open(uartMessagesJson) as f:
            __uartMessages = json.load(f)["Incoming"]

        if message.split("/")[0] not in __uartMessages:
            print(f"WARNING!!! Message {message} not found in uartMessages.json")
        else:
            self.__specs = __uartMessages[message.split("/")[0]]
            self.__message_values = message.split("/")[1:]

    @property
    def shouldForceCrashAppForDebugging(self):
        print("self.__specs['Type']: ", self.__specs["Type"])
        return "CrashApp" in self.__specs["Type"]

    @property
    def isNewGrooveOnset(self):
        return "NewGrooveOnset" in self.__specs["Type"]

    @property
    def isInputGrooveVelocityScale(self):
        return "InputGrooveVelocityScale" in self.__specs["Type"]

    @property
    def isInputGrooveOffsetQuantization(self):
        return "InputGrooveOffsetQuantization" in self.__specs["Type"]

    @property
    def isRandomnessPot(self):
        return "RandomnessPot" in self.__specs["Type"]

    @property
    def isDensityPot(self):
        return "DensityPot" in self.__specs["Type"]

    @property
    def isGeneralPurposePot(self):
        return "GeneralPurposePot" in self.__specs["Type"]

    @property
    def isInterpolationSlider(self):
        return "InterpolationSlider" in self.__specs["Type"]

    @property
    def shouldSaveToStateA(self):
        return "SaveToStateA" in self.__specs["Type"]

    @property
    def shouldSaveToStateB(self):
        return "SaveToStateB" in self.__specs["Type"]

    @property
    def shouldRandomizeStateA(self):
        return "RandomizeStateA" in self.__specs["Type"]

    @property
    def shouldRandomizeStateB(self):
        return "RandomizeStateB" in self.__specs["Type"]

    @property
    def LoadFromPreset(self):
        return "LoadFromPreset" in self.__specs["Type"]

    @property
    def SaveToPreset(self):
        return "SaveToPreset" in self.__specs["Type"]


    @property
    def value(self):
        """
        :return:  timestep, velocity, offset for new groove onset
        :return:  velocity scale amount (from 0 to 1) for input groove velocity scale
        :return:  quantization amount (from 0 to 1) for input groove offset quantization
        :return:  pot_ix, value (from 0 to 1) for density pot
        :return:  pot_ix, value (from 0 to 1) for general purpose pot
        :return:  interpolation value (from 0 to 1) for interpolation slider
        :return:  None for save to state A, save to state B, randomize state A, randomize state B
        :return:
        """
        if self.isNewGrooveOnset:
            time_step = None
            velocity = None
            offset = None
            encoding_format_list = self.__specs["Format"].split("/")[1:]

            for ix, fmt in enumerate(encoding_format_list):
                if fmt == "{step}":
                    time_step = int(self.__message_values[ix])
                elif fmt == "{vel}":
                    velocity = np.round(float(self.__message_values[ix]) / self.__specs["MaxVel"], 2)
                elif fmt == "{off}":
                    offset = np.round(float(self.__message_values[ix]) / self.__specs["MaxOffset"] / 2, 2)
            return time_step, velocity, offset

        elif self.isInputGrooveVelocityScale:
            return np.round(float(self.__message_values[0]) / self.__specs["MaxValue"], 2)

        elif self.isInputGrooveOffsetQuantization:
            return np.round(float(self.__message_values[0]) / self.__specs["MaxValue"], 2)

        elif self.isRandomnessPot:
            return np.round(float(self.__message_values[0]) / self.__specs["MaxValue"], 2)

        elif self.isDensityPot:
            pot_ix = int(self.__message_values[0]) - 1
            value = np.round(float(self.__message_values[1])/self.__specs["MaxValue"], 2)
            return pot_ix, value

        elif self.isGeneralPurposePot:
            pot_ix = int(self.__message_values[0]) - 1
            value = np.round(float(self.__message_values[1])/self.__specs["MaxValue"], 2)
            return pot_ix, value

        elif self.isInterpolationSlider:
            return np.round(float(self.__message_values[0]) / self.__specs["MaxValue"], 2)

        elif self.shouldSaveToStateA:
            return None

        elif self.shouldSaveToStateB:
            return None

        elif self.shouldRandomizeStateA:
            return None

        elif self.shouldRandomizeStateB:
            return None

        elif self.LoadFromPreset:
            return int(self.__message_values[0])

        elif self.SaveToPreset:
            return int(self.__message_values[0])

        else:
            raise ValueError(f"Value Getter not Implemented for {self.__specs['Type']}")

    def __repr__(self):
        return f"Type: {self.__specs['Type']}" + f"\nMessage Values = {self.__message_values}"


if __name__ == "__main__":
    mm = OutgoingMessageManager(uartMessagesJson="./src/uartMessages.json")
    print(mm.uartMessages)

    # test incoming message groove
    msg = "G/12/100/500\n"
    im = IncomingMessage(uartMessagesJson="./src/uartMessages.json", message=msg)
    im.value

    # test incoming message save to state A
    msg = "SA/"
    im = IncomingMessage(uartMessagesJson="./src/uartMessages.json", message=msg)

    # test density pot 2 value
    msg = "DP/2/100\n"
    im = IncomingMessage(uartMessagesJson="./src/uartMessages.json", message=msg)
    im.value
    im.isDensityPot

